const header = document.querySelector('.site-header');
const progress = document.getElementById('progress');
const menu = document.querySelector('.menu-toggle');
const nav = document.getElementById('mainNav');

function onScroll(){
  const y = window.scrollY;
  header.classList.toggle('scrolled', y > 20);
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${max > 0 ? (y / max) * 100 : 0}%`;
}
window.addEventListener('scroll', onScroll, {passive:true});
onScroll();

menu?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menu.setAttribute('aria-expanded', String(open));
});
nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  menu?.setAttribute('aria-expanded','false');
}));

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, {threshold:.12});
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

document.querySelectorAll('details').forEach(detail => {
  detail.addEventListener('toggle', () => {
    if(detail.open){
      document.querySelectorAll('details[open]').forEach(other => {
        if(other !== detail) other.removeAttribute('open');
      });
    }
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const id = link.getAttribute('href');
    if(id && id !== '#'){
      const target = document.querySelector(id);
      if(target){
        e.preventDefault();
        target.scrollIntoView({behavior:'smooth', block:'start'});
      }
    }
  });
});

document.getElementById('buyButton')?.addEventListener('click', () => {
  // Replace this anchor with the real checkout URL when the payment provider is connected.
  console.info('Checkout placeholder: connect your real payment/checkout URL to #kaufen.');
});
